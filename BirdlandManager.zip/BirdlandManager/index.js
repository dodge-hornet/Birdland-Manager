require("dotenv").config();
const { Client, GatewayIntentBits } = require("discord.js");
const keepAlive = require("./server.js"); // import the keepAlive server

// Create a new Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

// When bot is ready
client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return; // ignore bots

  if (message.content === "c!user") {
    const member = message.member;
    const countingRole = message.guild.roles.cache.find(r => r.name === "Counter"); // <-- replace with exact role name
    const saveCount = 1.1; // 👈 replace this with however you are tracking saves

    if (!countingRole) {
      return message.reply("⚠️ The counting role doesn’t exist. Please create it first!");
    }

    // If user already has role, do nothing
    if (member.roles.cache.has(countingRole.id)) {
      return; // quiet ignore
    }

    // If user qualifies (saves >= 1 whole number)
    if (saveCount >= 1) {
      await member.roles.add(countingRole);
      message.channel.send(`${member} can now count in the +1 counting channel! 🎉`);
    }
  }
});

// Start the web server so UptimeRobot keeps it alive
keepAlive();

// Login to Discord
client.login(process.env.TOKEN);
